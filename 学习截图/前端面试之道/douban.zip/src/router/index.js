import Vue from 'vue'
import Router from 'vue-router'

import PagesView from '../views/PagesView'
import HomeView from '../views/HomeView'
import MovieView from '../views/MovieView'
import BookView from '../views/BookView'
import StatusView from '../views/StatusView'
import GroupView from '../views/GroupView'
import SubjectView from '../views/SubjectView'
import DetailView from '../views/DetailView'
import SearchView from '../views/SearchView'

Vue.use(Router)

// <router-view class="view"></router-view>
//<router-view class="view" name="subject"></router-view>
//<router-view class="view" name="search"></router-view>


export default new Router({
    routes: [{
            // 默认首页重定向到pages在app的<router-view class="view"></router-view>直接渲染PagesView
            path: '/',
            redirect: '/pages/'

        },
        {
            path: '/pages',
            component: PagesView,
            // PagesView页面上的额router-view对应显示它的子路由
            children: [{
                    path: '',
                    redirect: '/pages/home'
                },
                {
                    path: 'home',
                    name: 'HomeView',
                    component: HomeView
                },
                {
                    path: 'movie',
                    name: 'MovieView',
                    component: MovieView
                },
                {
                    path: 'book',
                    name: 'BookView',
                    component: BookView
                },
                {
                    path: 'status',
                    name: 'StatusView',
                    component: StatusView
                },
                {
                    path: 'group',
                    name: 'GroupView',
                    component: GroupView
                },
                {
                    path: 'detail/:id',
                    name: 'DetailView',
                    component: DetailView
                }
            ]
        },
        {
            path: '/pages/:classify/subject/:id',
            name: 'SubjectView',
            components: {
                default: PagesView,
                subject: SubjectView
            }
        },
        {
            path: '/search',
            name: 'SearchView',
            components: {
                default: PagesView,
                search: SearchView
            }
        },
        {
            path: '*',
            redirect: '/pages/'
        }
    ]
})