<template>
  <div class="pages-view">
    <!-- 父组件上自定义事件，子组件通过this.$emit('showTalion') -->
    <!-- 这里是定义了一个方法给子组件使用，没有数据的交互，只是通过子组件来控制 父上面的talion组件的显示和隐藏 -->
    <header-bar @showTalion="open"></header-bar>
  
    <router-view></router-view>
    <!-- 它也是通过子来控制talion变量 来控制talion-view的显示和隐藏 -->
    <!-- 自组建内加事件方法，方法内用this.$emit('closeTalion')来触发父组件对应的close方法 close方法开控制该组件的显示隐藏 -->
    <talion-view v-show="talion" @closeTalion="close"></talion-view>
  </div>
</template>

<script>
import HeaderBar from '../components/HeaderBar'
import TalionView from '../views/TalionView'

export default {
  name: 'pages-view',
  components: { HeaderBar, TalionView },
  data () {
    return {
      talion: ''
    }
  },
  methods: {
    open() {
      this.talion = 'open'
    },
    close() {
      this.talion = ''
    }
  }
}
</script>

<style scoped>

</style>
